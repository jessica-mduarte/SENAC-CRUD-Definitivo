<title>Lista de cadastros</title>
<!-- Chamando o arquivo de cabeçalho no começo da página -->
<?php
    include __DIR__ . '/includes/header.php';
?>
<?php

require __DIR__ . '/includes/db.php';

// Inicio - logica de busca

// $_GET pega o valor digitando no campo de busca (se existir)
// trim() remove espaços antes e depois do texto;

$busca = trim($_GET['busca'] ?? '');

// get é usado aqui para consultar dados , nao esta salvando nada.

// verifica se o usuario digitou algo 

if ($busca !== ''){
    // se tiver texto na busca , o sql filtra pelo nome ou email
    $sql = 'SELECT id, nome, email, telefone, foto, data_cadastro
            FROM cadastros
            WHERE nome LIKE :busca OR email LIKE :busca
            ORDER BY id DESC'; // ORDENA PELOS IDS DO MAIOR PRO MENOR (CADASTROS MAIS NOVOS PRIMEIRO)
//prepara o comando SQL 

$stmt = db()->prepare($sql);

// executa substituindo o placeholder :busca
// o % antes e depois permite buscar qualquer parte do nome/email
$stmt->execute([':busca' => "%$busca%"]);

} else {
    // se o campo de busca estiver vazio, lista tudo
    $sql = 'SELECT id, nome, email, telefone, foto, data_cadastro
    FROM cadastros
    ORDER BY id DESC';

$stmt = db()->prepare($sql);
$stmt->execute();    

}

// fetchAll() busca todos os resultados e retorna como array associativo
$registros = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fim logica de busca

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css' rel='stylesheet'>
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js'></script> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
</head>
<body class="bg-light bg-gradient p-4 align-items:center;">
    
<header class="bg-light text-dark text-center py-3 mt-auto">
        <nav class="navbar navbar-light">
        
        <h3 style="color: #1D3557"><img id="logo" src="images/cadastrosicon.png" class="img-fluid h-100 me-2" style="max-height: 1em;">Lista de cadastros</h3>
        <hr>

</nav>
    </header>

   

    <form method="get">
      <div class="col-md-3 col-sm-6">
    <div class="input-group input-group-sm">
        <input type="search" class="form-control" name="busca" placeholder="Pesquisar..." value="<?= htmlspecialchars($busca)?>">
        <button class="btn btn-primary" type="submit">Buscar</button>
    </div>
</div>

        

        <a href="listar.php">Limpar</a>
    </form>


<?php if (!$registros): ?>
    <!-- Se não houver resultados --> 
    <p>Nenhum cadastro encontrado.</p>

<?php else: ?>
<div class="col-md-8 col-sm-6">

    <p><a class="btn btn-success" href="formulario.php"><i class="fas fa-plus"></i> Novo cadastro</a>
  
    <!-- Dropdown toggle para exportação -->
    <div class="d-flex flex-row-reverse dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Download Tabela</button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <a class="dropdown-item" href="exportar_dados/exportar_xls.php">Exportar XLS</a>
                <a class="dropdown-item" href="exportar_dados/exportar_csv.php">Exportar CSV</a>
            </div>

</div>

    
    <table class="table table-hover" border ="1" cellpadding="8" cellspacing="0">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Telefone</th>
                <th>Foto</th>
                <th>Data de Cadastro</th>
                <th>Ações</th>
            </tr>
        </thead>
    

    <tbody>
        <?php

        // foreach -> estrutura que percorre todos os registros do banco
        // $registros -> lista com todos os cadastros vindos do banco
        // $r -> representa UM registro por vez dentro do loop

        foreach ($registros as $r):
            ?>

        <tr>
            <td><?= (int)$r['id'] ?></td>
            <td><?= htmlspecialchars($r['nome']) ?></td>
            <td><?= htmlspecialchars($r['email']) ?></td>
            <td><?= htmlspecialchars($r['telefone']) ?></td>

            <td>
                <?php if (!empty($r['foto'])): ?>
                    <img src="<?= htmlspecialchars($r['foto']) ?>" alt="Foto" style="max-width:80px; max-height:80px;">
                    <?php else: ?>
                        -
                    <?php endif; ?>    
            </td>
             
            <!-- Exibe data, se existir -->
            <td> 
                <?= htmlspecialchars($r['data_cadastro'] ??'')?>
            </td>

            <!-- Links para editar ou excluir -->
             <td> 
                <a class="btn btn-outline-info btn-sm" href="editar.php?id=<?= (int)$r['id'] ?>">Editar</a>
                <a data-bs-toggle="modal" data-bs-target="#excluir<?= (int)$r['id'] ?>" class="btn btn-danger btn-sm">
    Excluir
</a>

<!-- Configuração do Popup(Modal) -->
<div class="modal fade" id="excluir<?= (int)$r['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="excluirLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="excluirLabel">Excluir Usuário</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
                Tem certeza que deseja excluir esse registro?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <a href="deletar.php?id=<?= (int)$r['id'] ?>" class="btn btn-danger">Confirmar Exclusão</a>
            </div>
        </div>
    </div>
</div>
 </td>
    </tr>   
        <?php endforeach; ?>
                    
    </tbody>
    </table>
                    </div>
    <!-- Fim da tabela de resultados -->

    <?php endif; ?>
</body>
</div>
</html>

    <!-- Footer -->
    <?php include __DIR__ . '/includes/footer.php'; ?>
    
    
</body>
</html>