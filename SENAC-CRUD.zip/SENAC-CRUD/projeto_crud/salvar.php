<?php
// carrega a função db() para conectar no MySQL
require __DIR__ . '/includes/db.php';                    
 
// guardará mensagens de erro (se houver)
$erro = '';
 
// indica se salvou com sucesso                                            
$ok = false;                                            
 
// Só processa se o método da requisição for POST (veio do formulário)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 
// 1) Captura e limpa os dados enviados
// Pega os valores do formulário via método POST
// e usa trim() pra remover espaços extras no começo e no fim
 
  $nome     = trim($_POST['nome']     ?? '');            
  $email    = trim($_POST['email']    ?? '');
  $telefone = trim($_POST['telefone'] ?? '');
  
 
// 2) Validações simples (evita dados incorretos antes de gravar no banco)
// Verifica se o nome foi preenchido e tem pelo menos 3 caracteres
// mb_strlen() função nativa do PHP que conta caracteres corretamente, incluindo acentos (ex: "José" = 4)
 
if ($nome === '' || mb_strlen($nome) < 3) {
  $erro = 'Nome é obrigatório (mín. 3 caracteres).';
 
// Verifica se o e-mail está em formato válido (ex: nome@dominio.com)
  // filter_var() → função nativa do PHP usada pra validar ou filtrar valores
  // FILTER_VALIDATE_EMAIL → constante nativa do PHP que valida o formato de e-mail
 
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  $erro = 'E-mail inválido.';
 
// Verifica se o telefone foi preenchido e tem pelo menos 8 dígitos
  // preg_replace() → função nativa do PHP que substitui partes de texto usando expressões regulares
  // aqui ela remove tudo que NÃO for número (/D+ significa "qualquer caractere não numérico")
  // depois usamos mb_strlen() pra contar quantos dígitos sobraram
 
} elseif ($telefone === '' || mb_strlen(preg_replace('/\D+/', '', $telefone)) < 8) {
  $erro = 'Telefone inválido.';
}
 
  // ======================================================================
  // Upload da FOTO — só executa se não houve erro anterior
  // INÍCIO DO BLOCO (FOTO)
  // ======================================================================
  $foto = null; // valor padrão: sem foto
 
  // Se não teve erro de validação e o campo "foto" veio no POST
  if ($erro === '' && isset($_FILES['foto']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE) {
 
    // Verifica se houve erro no upload (constantes nativas UPLOAD_ERR_*)
    if ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
      $erro = 'Erro ao enviar a imagem.';
 
    } else {
 
      // (Opcional) Limite de tamanho: até 2MB
      if ($_FILES['foto']['size'] > 2 * 1024 * 1024) {
        $erro = 'Imagem muito grande (máx. 2MB).';
      }
 
      // Validar o tipo real do arquivo (pra garantir que é uma imagem de verdade)
      if ($erro === '') {
 
      // finfo → classe nativa do PHP usada pra descobrir o tipo real do arquivo
      // (MIME = tipo do arquivo, ex: image/jpeg, image/png, application/pdf, etc.)
        $finfo = new finfo(FILEINFO_MIME_TYPE);
 
      // $_FILES['foto']['tmp_name'] → caminho temporário onde o PHP guarda o arquivo
      // antes de mover pra pasta final (tipo uma área de “rascunho”)
        $mime  = $finfo->file($_FILES['foto']['tmp_name']);
 
      // Lista de tipos de imagem que o sistema aceita (extensão associada)
        $permitidos = [
          'image/jpeg' => 'jpg',
          'image/png' => 'png',
          'image/gif' => 'gif'
        ];
 
      // Verifica se o tipo detectado está na lista dos permitidos
      // Se não estiver, mostra erro ao usuário
        if (!isset($permitidos[$mime])) {
          $erro = 'Formato de imagem inválido. Use JPG, PNG ou GIF.';
        }
      }
 
   // Cria a pasta "uploads" se ainda não existir
      if ($erro === '') {
       $dirUpload = __DIR__ . '/uploads'; // __DIR__ mostra a pasta atual do arquivo
 
      if (!is_dir($dirUpload)) {
    // is_dir() verifica se a pasta existe.
    // mkdir() cria pastas
    // 0755 = permissão padrão (dono pode tudo)
    // true = cria subpastas se for preciso
        mkdir($dirUpload, 0755, true);
  }
}
 
    // Gera um nome único e adiciona a extensão correta
    // uniqid() cria um nome aleatório pra evitar arquivos com o mesmo nome
        $novoNome  = uniqid('img_', true) . '.' . $permitidos[$mime];
 
    // Caminho completo de onde o arquivo será salvo
        $destino   = $dirUpload . '/' . $novoNome;
 
    // move_uploaded_file() → função nativa do PHP que move o arquivo
    // do local temporário (tmp_name) para o destino final (uploads/)
        if (move_uploaded_file($_FILES['foto']['tmp_name'], $destino)) {
         
    // Guarda apenas o caminho relativo pra salvar no banco
          $foto = 'uploads/' . $novoNome;
        } else {
          $erro = 'Falha ao salvar a imagem no servidor.';
        }
      }
    }
  }
 
  // ======================================================================
  // FIM DO BLOCO UPLOAD DA FOTO
  // =====================================================================
 
 
 // 3) Se não houve erro de validação, tenta salvar os dados no banco
if ($erro === '') {
 
   try {
    // SQL com placeholders nomeados (evita SQL Injection)
    // Os dois-pontos (:) indicam variáveis que serão substituídas depois
    $sql = 'INSERT INTO cadastros (nome, email, telefone, foto)
            VALUES (:nome, :email, :telefone, :foto)';
 
 
    // db() → função personalizada que retorna a conexão PDO com o banco
    // prepare() → método nativo do PDO que "pré-compila" o SQL no servidor
    // isso aumenta a segurança e o desempenho, pois separa o comando SQL dos dados
    $query = db()->prepare($sql);
 
    // execute() → método nativo do PDO que executa o comando preparado
    // aqui passamos os valores que vão substituir os placeholders nomeados
    $query->execute([
      ':nome'     => $nome,
      ':email'    => $email,
      ':telefone' => $telefone,
      ':foto'     => $foto,
    ]);
 
    $ok = true;  // Marca que o cadastro foi salvo com sucesso
 
  // catch (PDOException $e) captura erros lançados pelo PDO (função nativa do PHP para exceções)
  } catch (PDOException $e) {
 
    // O código 23000 indica erro de violação de restrição (ex.: e-mail duplicado na coluna UNIQUE)
    if ($e->getCode() === '23000') {
      // mensagem amigável pro usuário
      $erro = 'Este e-mail já está cadastrado.';  
 
    // Qualquer outro erro mostra a mensagem técnica (útil para depuração ou aula)
    } else {
      $erro = 'Erro ao salvar: ' . $e->getMessage();
      // getMessage() → método nativo da classe Exception que devolve o texto do erro
    }
  }
}
 
 
?>
 
<!doctype html>
<meta charset="utf-8">
<title>Salvar</title>
 
<!-- Se deu tudo certo no cadastro, mostra mensagem de sucesso -->
<?php if ($ok): ?>
  <p>Dados salvos com sucesso!</p>
  <p><a href="formulario.php">Voltar</a></p>
 
<!-- Se não deu certo, entra aqui -->
<?php else: ?>
 
  <!-- Se existe mensagem de erro, exibe em vermelho -->
  <?php if ($erro): ?>
    <!-- htmlspecialchars() → função nativa do PHP que converte caracteres especiais em HTML seguro -->
    <!-- Evita que alguém insira tags HTML ou scripts maliciosos dentro da mensagem -->
    <p style="color:red;"><?= htmlspecialchars($erro) ?></p>
 
  <!-- Se chegou aqui sem erro e sem POST, o usuário acessou a página diretamente -->
  <?php else: ?>
    <p>Nada enviado.</p>
  <?php endif; ?>
 
  <!-- Link pra voltar pro formulário -->
  <p><a href="formulario.php">Voltar</a></p>
 
<?php endif; ?>
 