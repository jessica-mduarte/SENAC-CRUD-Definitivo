<?php
// Inicia a sessão nas páginas que incluam o header
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Recebe nome do user logado
$nome = $_SESSION['usuario']['nome'] ?? '';
?>

<header class="bg-dark text-light py-2 mb-4">
    <div class="container">
        <nav class="navbar navbar-dark navbar-expand-lg px-0">

            <!-- Inclui o cabeçalho -->
            <div class="d-flex align-items-center me-5">
                <img id="logo" src="images/baseicon.png" class="img-fluid me-2" style="max-height: 1.5em;" alt="Logo">
                <h3 class="mb-0" style="color: white;">CRUD Simples - PHP & MySQL</h3>
            </div>

            <!-- Alguns itens da Navbar (Cadastro e Usuarios) -->
            <ul class="navbar-nav flex-row">
                <li class="nav-item me-3">
                    <a class="nav-link py-3" href="formulario.php">Cadastro</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link py-3" href="listar.php">Usuários</a>
                </li>
            </ul>

            <!-- Opções de Login + Logout (com dropdown) -->
            <ul class="navbar-nav ms-auto">

                <?php if ($nome): ?>
                    <!-- Quando o user está logado, recebe botão de logout -->
                    <li class="nav-item dropdown">

                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown"
                           role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Olá, <?= htmlspecialchars($nome) ?>
                        </a>

                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li>
                                <a class="dropdown-item" href="logout.php">Sair</a>
                            </li>
                        </ul>

                    </li>

                <?php else: ?>
                    <!-- User não logado: recebe botão de login com modal -->
                    <li class="nav-item">
                        <button type="button"
                                class="btn btn-outline-primary"
                                data-bs-toggle="modal"
                                data-bs-target="#loginModal">
                            Clique aqui para fazer Login
                        </button>
                    </li>
                <?php endif; ?>

            </ul>

        </nav>
    </div>

   

    <!-- Config do Modal -->
    <div class="modal fade text-dark" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">

                <div class="modal-header text-dark">
                    <h5 class="modal-title" id="loginModalLabel">Faça seu Login</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">

                    <!-- Msg de erro -->
                    <?php if (isset($erro) && $erro): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
                    <?php endif; ?>

                    
                    <form method="post" id="loginForm" action="login.php">

                        <div class="text-center mb-3">
                            <img class="img-fluid" style="max-height: 120px;" src="images/loginicon.png" alt="Login">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">E-mail:</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Senha:</label>
                            <input type="password" class="form-control" name="senha" required>
                        </div>

                    </form>
                </div>

                <div class="modal-footer text-center">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="submit" form="loginForm" class="btn btn-primary">Entrar</button>
                </div>

            </div>
        </div>
    </div>

</header>
