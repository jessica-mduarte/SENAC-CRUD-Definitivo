<footer class ="bg-dark text-light text-center py-2 mt-auto fixed-bottom">
    <div class="center-text-div" >

 
    <h4>Curso PHP&MySQL &copy;2025 Senac</h4>
</div>
</footer>
</main>
</body>
</html>