 <?php include __DIR__ . '/includes/header.php'; ?>
<?php
session_start(); // inicia (ou retoma) a sessão pra poder ler $_SESSION
 
// se NÃO existir usuário logado na sessão...
if (!isset($_SESSION['usuario'])) {
  // manda o navegador pra tela de login com um aviso na URL
  header('Location: login.php?msg=login');
  exit; // para o script aqui (impede que a página continue carregando)
}
 
?>
 
<?php
// Mostra o nome do usuário logado e o link de sair (se houver sessão ativa)
$u = $_SESSION['usuario'] ?? null;
if ($u): ?>
  <p>Logado como: <b><?= htmlspecialchars($u['nome']) ?></b> | <a href="logout.php">Sair</a></p>
<?php endif; ?>
 
 
