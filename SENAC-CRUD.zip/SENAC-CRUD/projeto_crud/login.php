<?php

require __DIR__ . '/includes/db.php';

// Inicia a sessão
session_start();

$erro = '';

// Verifica se o form foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $senha = trim($_POST['senha'] ?? '');

    if ($email === '' || $senha === '') {
        $erro = 'Preencha e-mail e senha.';
    } else {

        // Busca usuário pelo e-mail e verifica a senha
        $sql = 'SELECT id, nome, senha_hash FROM usuarios WHERE email = :email';
        $st  = db()->prepare($sql);
        $st->execute([':email' => $email]);
        $u = $st->fetch(PDO::FETCH_ASSOC);
        if ($u && password_verify($senha, $u['senha_hash'])) {

    //  Memoriza(?) a sessão
            $_SESSION['usuario'] = [
                'id'   => (int)$u['id'],
                'nome' => $u['nome']
            ];

    //   Leva de volta para a página inicial.
            header("Location: formulario.php?msg=logado");
            exit;
        } else {
            $erro = 'E-mail ou senha incorretos.';
        }
    }
}
?>
