<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light bg-gradient">
    <div class="container-fluid">
        <div class="row">

            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2">
            
                <div class=" position-fixed start-0 top-0 border-end" style="width: 250px; overflow-y: auto;">
                    <div class="p-3 border-bottom">
                        <h5 class="mb-0">Índice</h5>
                    </div>
                        <div class="dorpdown-menu">
                    <nav class="nav flex-column p-3">
                        <a class="nav-link active" href="#introducao">
                            Introdução
                        </a>

                        </div>

                        <a class="nav-link" href="#capitulo1">
                            Capítulo 1
                        </a>
                        <a class="nav-link" href="#capitulo2">
                            Capítulo 2
                        </a>
                        <a class="nav-link" href="#capitulo3">
                            Capítulo 3
                        </a>
                        <a class="nav-link" href="#conclusao">
                            Conclusão


    
    
</body>
</html>